# Customer-Churn-Prediction-For-a-Music-Subscription-Service
Customer Churn Prediction For a Music Subscription Service (KKBOX)

See the jupyter notebook file for an extended project description and project code.
